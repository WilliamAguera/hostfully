export type BookingType = {
    id: string
    checkInDate: Date
    checkOutDate: Date
    placeId: string
    total: string
}
