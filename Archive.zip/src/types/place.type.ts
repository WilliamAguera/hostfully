export type PlaceType = {
    id: string,
    title: string,
    price: string,
    description: string,
    location: string
    image: string;
}
